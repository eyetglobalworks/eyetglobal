<?php
include("connection.php");
$val = isset($_POST['type']) ? $_POST['type'] : '';
if($val != ""){
 $sql = "SELECT * FROM products LEFT JOIN district_table on district_table.dis_id = products.product_dist_id where product_status = 1 and product_dist_id = '$val' ORDER BY product_id DESC LIMIT 6";
} else{
   $sql = "SELECT * FROM products where product_status = 1 ORDER BY product_id DESC LIMIT 6";  
}

    $query = $conn->query($sql);
     $html = "";
    while($rowData = $query->fetch_assoc()){  
            
           $html .= '<div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 margin" ><div class="brand_box">
                            <img src="images/'.$rowData['product_img'].'" alt="img" />
                            <h3>Rs.<strong class="red">'.$rowData['product_price'].'</strong></h3>
                            <span style="font-size: 19px;">'.$rowData['product_name'].'</span>
                            <i><img src="images/star.png"/></i>
                            <i><img src="images/star.png"/></i>
                            <i><img src="images/star.png"/></i>
                            <i><img src="images/star.png"/></i><h3><strong class="red"><a class="buynow" class="red" href="#">Buy Now</a></strong></h3>
                        </div></div>';
        $type = $rowData['dis_name'];
    }
     echo $html.",".$type;

