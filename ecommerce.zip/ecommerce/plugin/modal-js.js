window.onload = function () {
    /* Cache the popup. */
    var popup = document.getElementById("popup");

    /* Show the popup. */
    popup.classList.remove("hidden");

    /* Fade the popup in */
    setTimeout(() => popup.classList.add("fade-in"));

    $('#close_btn').click(function () {
        $('.pop-bg').hide();
        popup.classList.remove("fade-in");
        setTimeout(() => popup.classList.add("hidden"), 300);
    });
    $('#search_id').on('click', function () {
        var type = $("#exampleFormControlSelect1").val();

        $("#id_products").empty();
        $.ajax({
            type: 'POST',
            url: 'districtchange.php',
            data: {
                'type': type,
            },
            success: function (data) {
                $("#id_products").empty();
                var strs = data.split(",");
                $("#id_products").append(strs[0]);
                $('.pop-bg').hide();
                popup.classList.remove("fade-in");
                setTimeout(() => popup.classList.add("hidden"), 300);
                $("div#our_brand h2").html("Our Brand - " + strs[1]);
                $('html, body').animate({
                    scrollTop: $("#brand_id").offset().top
                }, 500);
            }
        });
    });
};