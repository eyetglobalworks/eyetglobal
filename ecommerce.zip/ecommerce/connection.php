<?php
	$conn = new mysqli('localhost', 'root', '', 'ecommerce_test_db');

	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}
	
?>